/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
import {
  QueryFormData,
  QueryFormMetric,
  QueryFormColumn,
} from '@superset-ui/core';

export interface PluginChartMekkoWhaleStylesProps {
  height: number;
  width: number;
}

export type PluginChartMekkoWhaleQueryFormData = QueryFormData & {
  groupby: QueryFormColumn[];
  metric: QueryFormMetric;
  secondary_metric: QueryFormMetric;
  sort_by: 'profit' | 'revenue' | 'profit_margin';
  sort_order: 'ASC' | 'DESC';
  positive_color: { r: number; g: number; b: number; a: number };
  negative_color: { r: number; g: number; b: number; a: number };
  y_axis_format: string;
  x_axis_format: string;
};

export interface MekkoWhaleDataItem {
  name: string;
  value: [
    number, // xStart
    number, // xEnd
    number, // yStart
    number, // yEnd
    number, // metric (profit)
    number, // secondary_metric (revenue)
  ];
  itemStyle: {
    color: string;
  };
}

export type PluginChartMekkoWhaleProps = PluginChartMekkoWhaleStylesProps & {
  data: MekkoWhaleDataItem[];
  xAxisLabel: string;
  yAxisLabel: string;
  xAxisFormat: string;
  yAxisFormat: string;
  yMin: number;
  yMax: number;
  xMax: number;
};
